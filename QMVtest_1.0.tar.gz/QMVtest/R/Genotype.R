#' @title a dataset of simulated genotype matrix 
#'
#' @description 
#' A dataset of simulated genotype matrix with each row as a different individual and each column as a separate SNP. Each genotype is coded as 0, 1 or 2 for females and coded as 0 or 1 for males, indicating the number of reference allele.
#' 
#' @docType data
#' @keywords datasets
#' @name Genotype
#' @usage Genotype
#' @format a dataset for 4000 unrelated individuals and 31 SNPs.
NULL
