#' @title a numeric genotype matrix with each row as a different individual and each column as a separate snp.
#'
#' @description 
#' For females, each genotype is coded as 0, 1, 2, and NA for AA, Aa, aa, and missing; for males, each genotype is coded as 0, 1, and NA for A, a, and missing.
#' 
#' @docType data
#' @keywords datasets
#' @name Genotype
#' @usage Genotype
#' @format a data for 4000 individuals and 31 SNPs.
NULL
