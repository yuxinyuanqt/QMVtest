#' @title Read PLINK bed files into R, and compute the p-values and the test statistics of the location tests, the scale test, the location-scale tests or all
#' @description 
#' A function to obtain the \emph{p}-values and the test statistics of the location tests (i.e., QXcat and QZmax), the scale test (i.e.,wM3VNA3.3), the location-scale tests (i.e., QMVXcat and QMVZmax) or all. This function takes the path to the file of genotype with extension ".bed" (\code{bedfile}), and possibly additional path to the file of covariates (\code{Covariate_path}) in the sample population, as input. 
#' 
#' @usage
#' QMV_test_bed(bedfile,fastImpute=FALSE,
#'              Covariate_path=NULL,
#'              Covariate_missing = NA,
#'              Covariate.header=FALSE,
#'              missing_cutoff=0.15,
#'              MAF_Cutoff=NULL,
#'              MGC_Cutoff=20,
#'              method='joint')
#' 
#' @param bedfile Path to the file of genotype with extension ".bed" to read. The corresponding files with extensions ".bim" and ".fam" should be in the same directory.
#' @param fastImpute Logical scalar defaulting to False (or F) indicating no imputation for missing genotypes. If fastImpute=TURE, imputation is conducted by a fast imputation algorithm based on local XGBoost models (\code{\link{bigsnpr::snp_fastImpute}}).  
#' @param Covariate_path Path to the file of possibly additional covariates to read. This file should be a text file, one line per sample, with C+6 columns, where C is the number of covariates. The former six columns should be Family ID (FID), Individual ID  (IID), Paternal within-family ID (PID), Maternal within-family ID (MID), Sex and Phenotype. 
#' @param Covariate_missing The input variable "covariate_missing" is the missing value for the covariates in the data file, and the default value is NA.
#' @param Covariate.header Logical scalar defaulting to False (or F) indicating whether the covariate file contains variable names or not.
#' @param missing_cutoff Cutoff of the missing rates of SNPs (default=0.15). Any SNPs with missing rates higher than the cutoff will be excluded from the analysis.
#' @param MAF_Cutoff MAF cutoff for common vs. rare variants (default=NULL). It should be a numeric value between 0 and 0.5, or NULL. When it is NULL, 1/ sqrt(2 SampleSize) will be used (Ionita-Laza et al. 2013). Only common variants are included in the analysis.
#' @param MGC_Cutoff Cutoff for the minimum genotype count in either females or males (default=20), SNPs whose minimum genotype counts are less than this cutoff will not be included in the analysis. This is based on the quality control that SNPs with a minimum count below 20 should be removed to avoid inflated type I errors (Deng et al., 2019; Soave et al., 2015).
#' @param method A character string indicating which kind of association tests is to be conducted. There are four options: "location", "scale", "joint" (default) and "all". method="location": QXcat and QZmax; method="scale": wM3VNA3.3; method="joint": QMVXcat and QMVZmax; method="all": all of the above association tests.
#' 
#' @details 
#' QMVXcat and QMVZmax are designed to test for both the mean differences and the variance heterogeneity of the trait value across genotypes. QXcat and QZmax are used for testing the mean differences of the trait value only. wM3VNA3.3 is for testing the variance heterogeneity only.
#' 
#' @import expm
#' @import stats
#' @import mvtnorm
#' @import quantreg
#' @import bigsnpr
#' @import xgboost
#' @importFrom utils read.table
#' 
#' @return the \emph{p}-values and the test statistics of association tests selected by the method option for each SNP.
#' @export QMV_test_bed
#' 
#' @examples
#' 
#' path <- system.file("extdata", package = "QMVtest")
#' 
#' QMV_test_bed(paste(path,"example-missing.bed",sep = '/'),
#'              fastImpute=FALSE,
#'              Covariate_path=paste(path,"Covariate.txt",sep = '/'),
#'              Covariate_missing = NA,
#'              Covariate.header=TRUE,
#'              missing_cutoff=0.15,
#'              MAF_Cutoff=NULL,
#'              MGC_Cutoff=20,
#'              method='joint')
#' 
#' @author Yu-Xin Yuan, Zi-Ying Yang and Ji-Yuan Zhou
#' 
#' @references Yang ZY, Liu W, Yuan YX, et al. Robust association tests for quantitative traits on the X chromosome. 2022
#' @references Deng WQ, Mao S, Kalnapenkis A, et al. Analytical strategies to include the X-chromosome in variance heterogeneity analyses: evidence for trait-specific polygenic variance structure. \emph{Genetic Epidemiology}, 2019, \strong{43}: 815-830. 
#' @references Ionita-Laza I, Lee S, Makarov V, et al. Sequence kernel association tests for the combined effect of rare and common variants. \emph{The American Journal of Human Genetics}, 2013, \strong{92}: 841-853. 
#' @references Soave D, Corvol H, Panjwani N, et al. A joint location-scale test improves power to detect associated SNPs, gene sets, and pathways. \emph{The American Journal of Human Genetics}, 2015, \strong{97}: 125–138. 
#' 

QMV_test_bed <- function(bedfile,fastImpute=FALSE,
                         Covariate_path=NULL,
                         Covariate_missing = NA,
                         Covariate.header=FALSE,
                         missing_cutoff=0.15,
                         MAF_Cutoff=NULL,
                         MGC_Cutoff=20,
                         method='joint'){
  
  rds <- bigsnpr::snp_readBed(bedfile)
  fake <- bigsnpr::snp_attach(rds)
  if(fastImpute){
    G <- fake$genotypes
    CHR <- fake$map$chromosome
    infos <- bigsnpr::snp_fastImpute(G, CHR)
    fake$genotypes$code256 <- CODE_IMPUTE_PRED
  }
  pedfile <- cbind(fake$fam,fake$genotypes[])
  mapfile <- fake$map
  colnames(pedfile) <- c('FID','IID','PID','MID',
                         'Sex','Phenotype',mapfile[,2])
  if(!is.null(Covariate_path)){
    Covarfile <- read.table(Covariate_path,header = Covariate.header)
    if(Covariate.header==FALSE){
      colnames(Covarfile) <- c('FID','IID','PID','MID',
                               'Sex','Phenotype',
                               paste('Covar',1:(ncol(Covarfile)-6),sep='_'))
    } else{
      colnames(Covarfile)[1:6] <- c('FID','IID','PID','MID',
                                    'Sex','Phenotype')
    }
    if(!is.na(Covariate_missing)){
      Covarfile[,-6:-1] <- apply(Covarfile[,-6:-1],2,function(x){
        x[x==Covariate_missing] <- NA
        return(x)
      })
    }
    merge_data <- merge(pedfile,Covarfile[,-3:-6], by=c("FID","IID"),sort = FALSE)
    pedata <- merge_data[,seq(ncol(pedfile))]
    Covdata <- merge_data[,-seq(ncol(pedfile))]
  } else{
    pedata <- pedfile
    Covdata <- NULL
  }
  test_res <- QMV_test(pedata[,-1:-6],Y=pedata$Phenotype,
                       Sex = pedata$Sex,Covariate=Covdata,
                       missing_cutoff,
                       MAF_Cutoff,
                       MGC_Cutoff,
                       method)
  Tstat <- merge(mapfile,test_res$Tstat,by.x='marker.ID',
                 by.y='SNP',sort = FALSE)
  pvalue <- merge(mapfile,test_res$pvalue,by.x='marker.ID',
                  by.y='SNP',sort = FALSE)
  results <- list(Tstat=Tstat,pvalue=pvalue)
  return(results)
}