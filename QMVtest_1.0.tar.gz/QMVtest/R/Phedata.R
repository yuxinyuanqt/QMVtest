#' @title a phenotype(Y) and covariates(Sex,age,BMI) data for 4000 individuals.
#'
#' @description 
#' \code{Phedata$Sex} must be a vector of 1's and 2's following PLINK default coding, where males are coded as 1 and females 2.
#' 
#' @docType data
#' @keywords datasets
#' @name Phedata
#' @usage Phedata
#' @format a data for 4000 individuals and 4 variables.
#' \describe{
#' \item{Y}{a numeric variable of quantitative trait.}
#' \item{Sex}{the genetic sex of individuals in the sample population.}
#' \item{age}{the age of individuals in the sample population}
#' \item{BMI}{Body mass index}
#' }
NULL
