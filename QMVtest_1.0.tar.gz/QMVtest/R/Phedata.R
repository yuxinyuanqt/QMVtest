#' @title a dataset of simulated phenotype and covariates
#'
#' @description 
#' A dataset of simulated phenotype and covariates including sex, age and BMI. 
#' 
#' @docType data
#' @keywords datasets
#' @name Phedata
#' @usage Phedata
#' @format a dataset for 4000 unrelated individuals and four variables, including one phenotype and three covariates.
#' \describe{
#' \item{Y}{the values of the quantitative trait of individuals in the simulated dataset.}
#' \item{Sex}{the genetic sex of individuals, coded as 1 for males and coded as 2 for females, following the PLINK default coding.}
#' \item{age}{age of individuals in the simulated dataset.}
#' \item{BMI}{body mass index of individuals in the simulated dataset.}
#' }
NULL
