#' @title Levene's regression tests for variance homogeneity by SNP genotype
#' @description 
#' This function takes as input the genotype of SNPs (\code{Genotype}), the SEX (\code{Sex}), a quantitative trait (\code{Y}) in a sample population, and possibly additional covariates, such as principal components. The function then returns the variance heterogeneity \emph{p}-values using the generalized Levene's test (Deng et al., 2019).
#' 
#' @usage
#' scale_test(Genotype,Y,Sex,
#'            Covariate=NULL,
#'            missing_cutoff=0.15,
#'            MAF_Cutoff=NULL,
#'            MGC_Cutoff=30)
#' 
#' @param Genotype a numeric genotype matrix with each row as a different individual and each column as a separate snp, must contain values 0, 1, 2's coded for the number of reference allele.The length/dimension of \code{Genotype} should match that of \code{Y}, and/or \code{Sex} and \code{Covariate}.
#' @param Y a numeric vector of quantitative trait, such as human height.
#' @param Sex the genetic sex of individuals in the sample population, must be a vector of 1's and 2's following PLINK default coding, where males are coded as 1 and females 2.
#' @param Covariate optional: a vector or a matrix of covariates, such as age, BMI or principal components.
#' @param missing_cutoff a cutoff of the missing rates of SNPs (default=0.15). Any SNPs with missing rates higher than the cutoff will be excluded from the analysis.
#' @param MAF_Cutoff MAF cutoff for common vs rare variants (default=NULL). It should be a numeric value between 0 and 0.5, or NULL. When it is NULL, 1/ sqrt(2 SampleSize)  will be used.Only common variants are included in the analysis.
#' @param MGC_Cutoff Cutoff for the minimum genotype count in either females/males (default=30), SNPs whose minimum genotype count are less than this Cutoff will not be included in the analysis.This is based on the quality control that SNPs with a minimum count below 30 should be removed to avoid inflated type I errors (Deng et al., 2019; Soave et al., 2015).
#' 
#' @details 
#' Deng et al. (2019) assumed that the associations between SNPs and the quantitative trait under study could be biased by sex-specific means or variances because of the different numbers of the copies of X chromosome between females and males. In this regard, wM3VNA3.3 (Model-based three-degree of freedom test for variance heterogeneity associated with non-additive genotype) was proposed.
#' 
#' @import stats
#' @import methods
#' @import quantreg
#' 
#' @return the Levene's test regression \emph{p}-value according to the model specified.
#' 
#' @export scale_test
#' 
#' @examples
#' #Phedata: phenotype(Y) and covariates(Sex,age and BMI) data for 4000 individuals
#' data(Phedata)
#' #Genotype: a data for 4000 individuals and 31 SNPs
#' data(Genotype)
#' 
#' #scale test
#' #no covariate
#' #set "Covariate=NULL"
#' scale_test(Genotype,Phedata$Y,
#'            Phedata$Sex,
#'            Covariate=NULL,
#'            missing_cutoff=0.15,
#'            MAF_Cutoff=NULL,
#'            MGC_Cutoff=10)
#'  
#' #age and BMI as covariates
#' scale_test(Genotype,Phedata$Y,
#'            Phedata$Sex,
#'            Covariate=Phedata[,c(-1,-2)],
#'            missing_cutoff=0.15,
#'            MAF_Cutoff=NULL,
#'            MGC_Cutoff=10)
#'
#' @author Zi-Ying Yang, Wei Liu, Yu-Xin Yuan and Ji-Yuan Zhou
#' 
#' @references Zi-Ying Yang, Wei Liu, Yu-Xin Yuan, Yi-Fan Kong, Pei-Zhen Zhao, Wing Kam Fung and Ji-Yuan Zhou. (2022) Robust association tests for quantitative traits on the X chromosome.
#' @references Wei Q. Deng, Shihong Mao, Anette Kalnapenkis, Tõnu Esko, Reedik Mägi, Guillaume Paré and Lei Sun. (2019) Analytical strategies to include the X-chromosome in variance heterogeneity analyses: Evidence for trait-specific polygenic variance structure. \emph{Genet Epidemiol}. \strong{43}(7):815-830. \doi{10.1002/gepi.22247}. PMID:31332826.
#' @references David Soave, Harriet Corvol, Naim Panjwani, Jiafen Gong, Weili Li, Pierre-Yves Boëlle, Peter R. Durie, Andrew D. Paterson, Johanna M. Rommens, Lisa J. Strug and Lei Sun. (2015) A Joint Location-Scale Test Improves Power to Detect Associated SNPs, Gene Sets, and Pathways. \emph{American journal of human genetics}. \strong{97}(1): 125–138. \doi{10.1016/j.ajhg.2015.05.015}. PMID: 26140448.
#' 

scale_test <- function(Genotype,Y,Sex,
                       Covariate=NULL,
                       missing_cutoff=0.15,
                       MAF_Cutoff=NULL,
                       MGC_Cutoff=30){
  if (missing(Genotype)){
    stop("The Genotype input is missing.") 
  }
  if (missing(Y)){
    stop("The quantitative trait input is missing.")
  }
  if (missing(Sex)){
    stop("The Sex input is missing.")
  }
  if(!all(unique(Sex) %in% c(1,2))){
    stop('Sex must be a vector of 1(males) and 2(females)')
  }
  if (length(table(Sex))==1){
    stop("Only Males or Females detected")
  }
  Sex[Sex==2] <- 0
  if(!is.null(Covariate) & (is.matrix(Covariate)| 
                            is.vector(Covariate)|
                            is.data.frame(Covariate))){
    Covariate <- as.data.frame(Covariate)
    if(length(unique(c(length(Y),nrow(Covariate),nrow(Genotype),length(Sex))))!=1){
      stop("Make sure the inputs have the same length!")
    }
    Phedata <- cbind(Y,Covariate)
    Null_Model_string <- paste('Y',paste(colnames(Covariate), collapse = "+"),sep = "~")
  }else if(is.null(Covariate)){
    Phedata <- as.data.frame(Y)
    if(length(unique(c(length(Y),nrow(Genotype),length(Sex))))!=1){
      stop("Make sure the inputs have the same length!")
    }
    Null_Model_string <- 'Y~1'
  }else{
    stop("Covariate must be a vector or a matrix!")
  }
  if(is.vector(Genotype)){
    Genotype <- as.matrix(Genotype)
  } 
  if(is.null(MAF_Cutoff)){
    MAF_Cutoff <- 1/sqrt(2*length(Sex))
  }
  MAF_w <- ifelse(Sex==0,0.5,1)
  drop_index <- apply(Genotype,2,function(snp){
    table_snp_sex <- table(factor(interaction(snp, Sex)))
    index1 <- length(table_snp_sex) < 5
    missing_ratio <- mean(is.na(snp))
    MAF_Genotype <- mean(snp*MAF_w,na.rm=TRUE)
    index2 <- missing_ratio>=missing_cutoff
    index3 <- MAF_Genotype<MAF_Cutoff
    index4 <- any(table_snp_sex<MGC_Cutoff)
    index <- index1 | index2 | index3 | index4
  })
  Genotype <- Genotype[,!drop_index,drop=F]
  if(ncol(Genotype)==0){
    stop("No snp meets the inclusion criteria!")
  }
  res <- as.matrix(apply(Genotype, 2, function(snp){
    lm_resid <- resid(lm(as.formula(Null_Model_string),na.action = na.exclude,data = Phedata))
    res_geno_sexInt <- try(as.numeric(resid(quantreg::rq(lm_resid~snp*Sex,na.action=na.exclude, method="fn"))),silent=TRUE)
    if (methods::is(res_geno_sexInt, "try-error")){next}
    VAR <- tapply(lm_resid, Sex, sd)
    w <- ifelse(Sex == 0, VAR[1], VAR[2])
    r1_geno_SexInt <- res_geno_sexInt/w
    wM3VNA3.3 <- anova(lm(abs(r1_geno_SexInt)~Sex+factor(snp)+I(ifelse(snp!=0 & Sex==1,1,0))), lm(abs(r1_geno_SexInt)~Sex))$Pr[2]
  }))
  colnames(res) <- 'wM3VNA3.3'
  SNPnames <- rownames(res)
  if(is.null(SNPnames)){
    SNPnames <- paste('snp',seq(ncol(Genotype)),sep = "")
  }
  results <- data.frame(SNP=SNPnames,res,row.names = NULL)
  return(results)
}
