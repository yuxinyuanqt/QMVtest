#' @title Sex stratified X chromosome location (mean-based association) tests for quantitative traits
#' 
#' @description 
#' This function takes as input the genotype of SNPs (\code{Genotype}), the SEX (\code{Sex}), a quantitative trait (\code{Y}) in a sample population, and possibly additional covariates, such as principal components. The function returns the location association \emph{p}-values for each SNP (Yang et al., 2021).
#' 
#' @usage 
#' location_test(Genotype,Y,Sex,
#'               Covariate=NULL,
#'               missing_cutoff=0.15,
#'               MAF_Cutoff=NULL,
#'               MGC_Cutoff=30)
#' 
#' 
#' @param Genotype a numeric genotype matrix with each row as a different individual and each column as a separate snp, must contain values 0, 1, 2's coded for the number of reference allele. The length/dimension of \code{Genotype} should match that of \code{Y}, and/or \code{Sex} and \code{Covariate}.
#' @param Y a numeric vector of quantitative trait, such as human height.
#' @param Sex the genetic sex of individuals in the sample population, must be a vector of 1's and 2's following PLINK default coding, where males are coded as 1 and females 2.
#' @param Covariate optional: a vector or a matrix of covariates, such as age, BMI or principal components.
#' @param missing_cutoff a cutoff of the missing rates of SNPs (default=0.15). Any SNPs with missing rates higher than the cutoff will be excluded from the analysis.
#' @param MAF_Cutoff MAF cutoff for common vs rare variants (default=NULL). It should be a numeric value between 0 and 0.5, or NULL. When it is NULL, 1/ sqrt(2 SampleSize) will be used. Only common variants are included in the analysis.
#' @param MGC_Cutoff Cutoff for the minimum genotype count in either females/males (default=30), SNPs whose minimum genotype count are less than this Cutoff will not be included in the analysis. This is based on the quality control that SNPs with a minimum count below 30 should be removed to avoid inflated type I errors (Deng et al., 2019; Soave et al., 2015).
#' 
#' @details 
#' There are 2 types of Sex stratified X chromosome location (mean-based association) tests: QXcat and QZmax. QXcat: Sex stratified X chromosome association test for quantitative traits considering various XCI patterns; QZmax: Sex stratified X chromosome association test for quantitative traits considering different dosage compensation patterns.
#' 
#' @import expm
#' @import stats
#' @import mvtnorm
#' 
#' @return \emph{p}-values of QXcat and QZmax for each SNP.
#' @export location_test
#' 
#' @note QXcat and QZmax are designed for testing mean differences of the trait value. In QXcat, we obtain the \emph{p}-values for females and males, respectively, by testing mean differences of the trait value via weighted linear regression models. Then, we combine these two \emph{p}-values together by Fisher's method. In QZmax, we use different sample sizes as weights, which stand for different dosage compensation patterns according to Wang et al. (2019), to combine the test statistics for females and males.
#' 
#' @examples
#' #Phedata: phenotype(Y) and covariates(Sex, age and BMI) data for 4000 individuals
#' data(Phedata)
#' #Genotype: a data for 4000 individuals and 31 SNPs
#' data(Genotype)
#' 
#' #location test
#' #no covariate
#' #set "Covariate=NULL"
#' location_test(Genotype,Phedata$Y,
#'               Phedata$Sex,
#'               Covariate=NULL,
#'               missing_cutoff=0.15,
#'               MAF_Cutoff=NULL,MGC_Cutoff=10)
#'  
#' #age and BMI as covariates
#' location_test(Genotype,Phedata$Y,
#'               Phedata$Sex,
#'               Covariate=Phedata[,c(-1,-2)],
#'               missing_cutoff=0.15,
#'               MAF_Cutoff=NULL,MGC_Cutoff=10)
#'
#' @author Zi-Ying Yang, Wei Liu, Yu-Xin Yuan and Ji-Yuan Zhou
#' 
#' @references Zi-Ying Yang, Wei Liu, Yu-Xin Yuan, Yi-Fan Kong, Pei-Zhen Zhao, Wing Kam Fung and Ji-Yuan Zhou. (2022) Robust association tests for quantitative traits on the X chromosome.
#' @references Wei Q. Deng, Shihong Mao, Anette Kalnapenkis, Tõnu Esko, Reedik Mägi, Guillaume Paré and Lei Sun. (2019) Analytical strategies to include the X-chromosome in variance heterogeneity analyses: Evidence for trait-specific polygenic variance structure. \emph{Genet Epidemiol}. \strong{43}(7):815-830. \doi{10.1002/gepi.22247}. PMID:31332826.
#' @references David Soave, Harriet Corvol, Naim Panjwani, Jiafen Gong, Weili Li, Pierre-Yves Boëlle, Peter R. Durie, Andrew D. Paterson, Johanna M. Rommens, Lisa J. Strug and Lei Sun. (2015) A Joint Location-Scale Test Improves Power to Detect Associated SNPs, Gene Sets, and Pathways. \emph{American journal of human genetics}. \strong{97}(1): 125–138. \doi{10.1016/j.ajhg.2015.05.015}. PMID: 26140448.
#' @references Peng Wang, Si-Qi Xu, Bei-Qi Wang, Wing Kam Fung and Ji-Yuan Zhou. (2019) A robust and powerful test for case-control genetic association study on X chromosome. \emph{Statistical Methods in Medical Research}. \strong{28}(10-11):3260-3272. \doi{10.1177/0962280218799532}. PMID: 30232923.
#' 

location_test <- function(Genotype,Y,Sex,
                          Covariate=NULL,
                          missing_cutoff=0.15,
                          MAF_Cutoff=NULL,
                          MGC_Cutoff=30){
  if (missing(Genotype)){
    stop("The Genotype input is missing.") 
  }
  if (missing(Y)){
    stop("The quantitative trait input is missing.")
  }
  if (missing(Sex)){
    stop("The Sex input is missing.")
  }
  if(!all(unique(Sex) %in% c(1,2))){
    stop('Sex must be a vector of 1(males) and 2(females)')
  }
  if (length(table(Sex))==1){
    stop("Only Males or Females detected")
  }
  Sex[Sex==2] <- 0
  if(!is.null(Covariate) & (is.matrix(Covariate)| 
                            is.vector(Covariate)|
                            is.data.frame(Covariate))){
    Covariate <- as.data.frame(Covariate)
    if(length(unique(c(length(Y),nrow(Covariate),nrow(Genotype),length(Sex))))!=1){
      stop("Make sure the inputs have the same length!")
    }
    Phedata <- cbind(Y,Covariate)
    Null_Model_string <- paste('Y',paste(colnames(Covariate), collapse = "+"),sep = "~")
  }else if(is.null(Covariate)){
    Phedata <- as.data.frame(Y)
    if(length(unique(c(length(Y),nrow(Genotype),length(Sex))))!=1){
      stop("Make sure the inputs have the same length!")
    }
    Null_Model_string <- 'Y~1'
  }else{
    stop("Covariate must be a vector or a matrix!")
  }
  if(is.vector(Genotype)){
    Genotype <- as.matrix(Genotype)
  } 
  if(is.null(MAF_Cutoff)){
    MAF_Cutoff <- 1/sqrt(2*length(Sex))
  }
  MAF_w <- ifelse(Sex==0,0.5,1)
  drop_index <- apply(Genotype,2,function(snp){
    table_snp_sex <- table(factor(interaction(snp, Sex)))
    index1 <- length(table_snp_sex) < 5
    missing_ratio <- mean(is.na(snp))
    MAF_Genotype <- mean(snp*MAF_w,na.rm=TRUE)
    index2 <- missing_ratio>=missing_cutoff
    index3 <- MAF_Genotype<MAF_Cutoff
    index4 <- any(table_snp_sex<MGC_Cutoff)
    index <- index1 | index2 | index3 | index4
  })
  Genotype <- Genotype[,!drop_index,drop=F]
  if(ncol(Genotype)==0){
    stop("No snp meets the inclusion criteria!")
  }
  fnMatSqrtInverse = function(mA) {
    solve(expm::sqrtm(mA))
  }
  Phedataf <- subset(Phedata,Sex==0)
  Phedatam <- subset(Phedata,Sex==1)
  nf <- nrow(Phedataf)
  nm <- nrow(Phedatam)
  myfitf_string <- paste(Null_Model_string,'+snp_AAf+snp_Af',sep = "")
  myfitm_string <- paste(Null_Model_string,'+snp_m',sep = "")
  res <- t(apply(Genotype, 2, function(snp){
    snp_f <- subset(snp,Sex==0)
    snp_AAf <- ifelse(snp_f==2,1,0) 
    snp_Af <- ifelse(snp_f!=0,1,0) 
    snp_m <- subset(snp,Sex==1)
    myfitf0 <- lm(as.formula(myfitf_string),na.action = na.exclude,data = Phedataf)
    nvarf <- myfitf0[['rank']]
    inv_varf <- tapply(resid(myfitf0),snp_f,function(x){
      (sum(!is.na(x))-nvarf)/((sum(!is.na(x))-1)*var(x,na.rm=T))})
    weightsf <- ifelse(snp_f==0,inv_varf[1],
                       ifelse(snp_f==1,inv_varf[2],inv_varf[3]))
    myfitf <- lm(as.formula(myfitf_string),data = Phedataf,
                 na.action = na.exclude,weights = weightsf)
    ncoef <- length(myfitf0$coefficients)
    betaf <- coefficients(myfitf)[(ncoef-1):ncoef]
    covf <- vcov(myfitf)[(ncoef-1):ncoef,(ncoef-1):ncoef]
    zf <- fnMatSqrtInverse(covf)%*%betaf
    pAf <- pt(zf,df=myfitf$df.residual,lower.tail = FALSE)
    myfitm0 <- lm(as.formula(myfitm_string), na.action = na.exclude,data = Phedatam)
    nvarm <- myfitm0[['rank']]
    inv_varm <- tapply(resid(myfitm0),snp_m,function(x){
      (sum(!is.na(x))-nvarm)/((sum(!is.na(x))-1)*var(x,na.rm=T))})
    weightsm <- ifelse(snp_m==0,inv_varm[1],inv_varm[2])
    myfitm <- lm(as.formula(myfitm_string),data = Phedatam, 
                 na.action = na.exclude,weights = weightsm)
    tm <- summary(myfitm)$coefficients[nvarm,3]
    pAm <- pt(tm,df=myfitm$df.residual,lower.tail = FALSE)
    q1 <- max(-2*log(pchisq(-2*log(prod(pAf)),4, lower.tail = FALSE)*pAm),
              -2*log(pchisq(-2*log(prod(1-pAf)),4, lower.tail = FALSE)*(1-pAm)))
    QXcat <- 2*pchisq(q1,4, lower.tail = FALSE)
    zfsum <- sum(zf)/sqrt(2)
    w1 <- (2*nf)/(nm+2*nf)     			
    w2 <- nf/(nm+nf)
    corr <- sqrt(w1*w2)+sqrt((1-w1)*(1-w2))
    corrp <- matrix(c(1,corr,corr,1),2)
    z1 <- sqrt(w1)*zfsum+sqrt(1-w1)*tm
    z2 <- sqrt(w2)*zfsum+sqrt(1-w2)*tm
    zmaxn <- max(abs(z1),abs(z2))
    QZmax <- 1 - mvtnorm::pmvnorm(lower=-rep(zmaxn,2), upper=rep(zmaxn,2), corr=corrp)
    res <- c(QXcat,QZmax)
    names(res) <- c('QXcat','QZmax')
    return(res)
  }))
  res[res>1] <- 1
  SNPnames <- rownames(res)
  if(is.null(SNPnames)){
    SNPnames <- paste('snp',seq(ncol(Genotype)),sep = "")
  }
  results <- data.frame(SNP=SNPnames,res,row.names = NULL)
  return(results)
}