#' @title A function to obtain the p-values of QXcat and QZmax for testing the mean differences of the trait value across genotypes
#' 
#' @description 
#' A function to obtain the \emph{p}-values of QXcat and QZmax in Yang et al. (2021) for testing the mean differences of the trait vaule across genotypes. This function takes as input the genotype of SNPs (\code{Genotype}), the sex (\code{Sex}), the quantitative trait (\code{Y}) in the sample population, and possibly additional covariates, such as age and BMI.
#' 
#' @usage 
#' location_test(Genotype,Y,Sex,
#'               Covariate=NULL,
#'               missing_cutoff=0.15,
#'               MAF_Cutoff=NULL,
#'               MGC_Cutoff=30)
#' 
#' 
#' @param Genotype A numeric genotype matrix with each row as a different individual and each column as a separate SNP. Each genotype should be code as 0, 1 or 2, indicating the number of reference allele. The length/dimension of \code{Genotype} should match that of \code{Y}, \code{Sex} and \code{Covariate}.
#' @param Y A numeric vector of a quantitative trait, such as human height.
#' @param Sex A vector of the genetic sex following PLINK default coding, where males are coded as 1 and females are coded as 2.
#' @param Covariate Optional: a vector or a matrix of covariates, such as age and BMI.
#' @param missing_cutoff Cutoff of the missing rates of SNPs (default=0.15). Any SNPs with missing rates higher than the cutoff will be excluded from the analysis.
#' @param MAF_Cutoff MAF cutoff for common vs rare variants (default=NULL). It should be a numeric value between 0 and 0.5, or NULL. When it is NULL, 1/ sqrt(2 SampleSize) will be used (Ionita-Laza et al. 2013). Only common variants are included in the analysis.
#' @param MGC_Cutoff Cutoff for the minimum genotype count in either females or males (default=30), SNPs whose minimum genotype count are less than this cutoff will not be included in the analysis. This is based on the quality control that SNPs with a minimum count below 30 should be removed to avoid inflated type I errors (Deng et al., 2019; Soave et al., 2015).
#' 
#' @details 
#' QXcat tests for the mean differences of the quantitative trait across different genotypes on the X chromosome by considering various X chromosome inactivation (XCI) patterns. QZmax tests for the different mean values of the trait across various genotypes on the X chromosome by considering different dosage compensation (DC) patterns.
#' 
#' @import expm
#' @import stats
#' @import mvtnorm
#' 
#' @return \emph{p}-values of the location tests QXcat and QZmax for each SNP.
#' @export location_test
#' 
#' @examples
#' #Phedata: phenotype (Y) and covariates (Sex, age and BMI) data for 4000 unrelated individuals
#' data(Phedata)
#' #Genotype: a data for 4000 unrelated individuals and 31 SNPs
#' data(Genotype)
#' 
#' #the location tests (i.e., QXcat and QZmax)
#' #no covariate
#' #set "Covariate=NULL"
#' location_test(Genotype,Phedata$Y,
#'               Phedata$Sex,
#'               Covariate=NULL,
#'               missing_cutoff=0.15,
#'               MAF_Cutoff=NULL,
#'               MGC_Cutoff=30)
#'  
#' #age and BMI as covariates
#' location_test(Genotype,Phedata$Y,
#'               Phedata$Sex,
#'               Covariate=Phedata[,c(-1,-2)],
#'               missing_cutoff=0.15,
#'               MAF_Cutoff=NULL,
#'               MGC_Cutoff=30)
#'
#' @author Yu-Xin Yuan, Zi-Ying Yang and Ji-Yuan Zhou
#' 
#' @references Yang ZY, Liu W, Yuan YX, et al. Robust association tests for quantitative traits on the X chromosome. 2022
#' @references Deng WQ, Mao S, Kalnapenkis A, et al. Analytical strategies to include the X-chromosome in variance heterogeneity analyses: Evidence for trait-specific polygenic variance structure. \emph{Genetic Epidemiology}, 2019, \strong{43}: 815-830. 
#' @references Ionita-Laza I, Lee S, Makarov V, et al. Sequence kernel association tests for the combined effect of rare and common variants. \emph{The American Journal of Human Genetics}, 2013, \strong{92}: 841-853. 
#' @references Soave D, Corvol H, Panjwani N, et al. A Joint Location-Scale Test Improves Power to Detect Associated SNPs, Gene Sets, and Pathways. \emph{The American journal of human genetics}, 2015, \strong{97}: 125–138. 
#' 

location_test <- function(Genotype,Y,Sex,
                          Covariate=NULL,
                          missing_cutoff=0.15,
                          MAF_Cutoff=NULL,
                          MGC_Cutoff=30){
  if (missing(Genotype)){
    stop("The Genotype input is missing.") 
  }
  if (missing(Y)){
    stop("The quantitative trait input is missing.")
  }
  if (missing(Sex)){
    stop("The Sex input is missing.")
  }
  if(!all(unique(Sex) %in% c(1,2))){
    stop('Sex must be a vector of 1(males) and 2(females)')
  }
  if (length(table(Sex))==1){
    stop("Only Males or Females detected")
  }
  Sex[Sex==2] <- 0
  if(!is.null(Covariate) & (is.matrix(Covariate)| 
                            is.vector(Covariate)|
                            is.data.frame(Covariate))){
    Covariate <- as.data.frame(Covariate)
    if(length(unique(c(length(Y),nrow(Covariate),nrow(Genotype),length(Sex))))!=1){
      stop("Make sure the inputs have the same length!")
    }
    Phedata <- cbind(Y,Covariate)
    Null_Model_string <- paste('Y',paste(colnames(Covariate), collapse = "+"),sep = "~")
  }else if(is.null(Covariate)){
    Phedata <- as.data.frame(Y)
    if(length(unique(c(length(Y),nrow(Genotype),length(Sex))))!=1){
      stop("Make sure the inputs have the same length!")
    }
    Null_Model_string <- 'Y~1'
  }else{
    stop("Covariate must be a vector or a matrix!")
  }
  if(is.vector(Genotype)){
    Genotype <- as.matrix(Genotype)
  } 
  if(is.null(MAF_Cutoff)){
    MAF_Cutoff <- 1/sqrt(2*length(Sex))
  }
  MAF_w <- ifelse(Sex==0,0.5,1)
  drop_index <- apply(Genotype,2,function(snp){
    table_snp_sex <- table(factor(interaction(snp, Sex)))
    index1 <- length(table_snp_sex) < 5
    missing_ratio <- mean(is.na(snp))
    MAF_Genotype <- mean(snp*MAF_w,na.rm=TRUE)
    index2 <- missing_ratio>=missing_cutoff
    index3 <- MAF_Genotype<MAF_Cutoff
    index4 <- any(table_snp_sex<MGC_Cutoff)
    index <- index1 | index2 | index3 | index4
  })
  Genotype <- Genotype[,!drop_index,drop=F]
  if(ncol(Genotype)==0){
    stop("No snp meets the inclusion criteria!")
  }
  fnMatSqrtInverse = function(mA) {
    solve(expm::sqrtm(mA))
  }
  Phedataf <- subset(Phedata,Sex==0)
  Phedatam <- subset(Phedata,Sex==1)
  nf <- nrow(Phedataf)
  nm <- nrow(Phedatam)
  myfitf_string <- paste(Null_Model_string,'+snp_AAf+snp_Af',sep = "")
  myfitm_string <- paste(Null_Model_string,'+snp_m',sep = "")
  res <- t(apply(Genotype, 2, function(snp){
    snp_f <- subset(snp,Sex==0)
    snp_AAf <- ifelse(snp_f==2,1,0) 
    snp_Af <- ifelse(snp_f!=0,1,0) 
    snp_m <- subset(snp,Sex==1)
    myfitf0 <- lm(as.formula(myfitf_string),na.action = na.exclude,data = Phedataf)
    nvarf <- myfitf0[['rank']]
    inv_varf <- tapply(resid(myfitf0),snp_f,function(x){
      1/var(x,na.rm=T)})
    weightsf <- ifelse(snp_f==0,inv_varf[1],
                       ifelse(snp_f==1,inv_varf[2],inv_varf[3]))
    myfitf <- lm(as.formula(myfitf_string),data = Phedataf,
                 na.action = na.exclude,weights = weightsf)
    ncoef <- length(myfitf0$coefficients)
    betaf <- coefficients(myfitf)[(ncoef-1):ncoef]
    covf <- vcov(myfitf)[(ncoef-1):ncoef,(ncoef-1):ncoef]
    zf <- fnMatSqrtInverse(covf)%*%betaf
    pAf <- pt(zf,df=myfitf$df.residual,lower.tail = FALSE)
    myfitm0 <- lm(as.formula(myfitm_string), na.action = na.exclude,data = Phedatam)
    nvarm <- myfitm0[['rank']]
    inv_varm <- tapply(resid(myfitm0),snp_m,function(x){
      1/var(x,na.rm=T)})
    weightsm <- ifelse(snp_m==0,inv_varm[1],inv_varm[2])
    myfitm <- lm(as.formula(myfitm_string),data = Phedatam, 
                 na.action = na.exclude,weights = weightsm)
    tm <- summary(myfitm)$coefficients[nvarm,3]
    pAm <- pt(tm,df=myfitm$df.residual,lower.tail = FALSE)
    q1 <- max(-2*log(pchisq(-2*log(prod(pAf)),4, lower.tail = FALSE)*pAm),
              -2*log(pchisq(-2*log(prod(1-pAf)),4, lower.tail = FALSE)*(1-pAm)))
    QXcat <- 2*pchisq(q1,4, lower.tail = FALSE)
    zfsum <- sum(zf)/sqrt(2)
    w1 <- (2*nf)/(nm+2*nf)     			
    w2 <- nf/(nm+nf)
    corr <- sqrt(w1*w2)+sqrt((1-w1)*(1-w2))
    corrp <- matrix(c(1,corr,corr,1),2)
    z1 <- sqrt(w1)*zfsum+sqrt(1-w1)*tm
    z2 <- sqrt(w2)*zfsum+sqrt(1-w2)*tm
    zmaxn <- max(abs(z1),abs(z2))
    QZmax <- 1 - mvtnorm::pmvnorm(lower=-rep(zmaxn,2), upper=rep(zmaxn,2), corr=corrp)
    res <- c(QXcat,QZmax)
    names(res) <- c('QXcat','QZmax')
    return(res)
  }))
  res[res>1] <- 1
  SNPnames <- rownames(res)
  if(is.null(SNPnames)){
    SNPnames <- paste('snp',seq(ncol(Genotype)),sep = "")
  }
  results <- data.frame(SNP=SNPnames,res,row.names = NULL)
  return(results)
}
