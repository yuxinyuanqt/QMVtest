#' @title A function to obtain the p-values and the test statistics of the location tests, the scale test, the location-scale tests or all
#' @description 
#' A function to obtain the \emph{p}-values and the test statistics of the location tests (i.e., QXcat and QZmax), the scale test (i.e.,wM3VNA3.3), the location-scale tests (i.e., QMVXcat and QMVZmax) or all.This function takes the genotype of SNPs (\code{Genotype}), the sex (\code{Sex}), the quantitative trait (\code{Y}) in the sample population, and possibly additional covariates, such as age and BMI, as input. 
#' 
#' @usage 
#' QMV_test(Genotype,Y,Sex,
#'          Covariate=NULL,
#'          missing_cutoff=0.15,
#'          MAF_Cutoff=NULL,
#'          MGC_Cutoff=30,
#'          method='joint')
#' 
#' @param Genotype A numeric genotype matrix with each row as a different individual and each column as a separate SNP. Each genotype is coded as 0, 1 or 2 for females and coded as 0 or 1 for males, indicating the number of reference allele. The length/dimension of \code{Genotype} should be the same to those of \code{Y}, \code{Sex} and \code{Covariate}.
#' @param Y A numeric vector of a quantitative trait, such as human height.
#' @param Sex A vector of the genetic sex following PLINK default coding, where males are coded as 1 and females are coded as 2.
#' @param Covariate Optional: a vector or a matrix of covariates, such as age and BMI.
#' @param missing_cutoff Cutoff of the missing rates of SNPs (default=0.15). Any SNPs with missing rates higher than the cutoff will be excluded from the analysis.
#' @param MAF_Cutoff MAF cutoff for common vs. rare variants (default=NULL). It should be a numeric value between 0 and 0.5, or NULL. When it is NULL, 1/ sqrt(2 SampleSize) will be used (Ionita-Laza et al. 2013). Only common variants are included in the analysis.
#' @param MGC_Cutoff Cutoff for the minimum genotype count in either females or males (default=30), SNPs whose minimum genotype counts are less than this cutoff will not be included in the analysis. This is based on the quality control that SNPs with a minimum count below 30 should be removed to avoid inflated type I errors (Deng et al., 2019; Soave et al., 2015).
#' @param method A character string indicating which kind of association tests is to be conducted. There are four options: "location", "scale", "joint" (default) and "all". method="location": QXcat and QZmax; method="scale": wM3VNA3.3; method="joint": QMVXcat and QMVZmax; method="all": all of the above association tests.
#' 
#' @details 
#' QMVXcat and QMVZmax are designed to test for both the mean differences and the variance heterogeneity of the trait value across genotypes. QXcat and QZmax are used for testing the mean differences of the trait value only. wM3VNA3.3 is for testing the variance heterogeneity only.
#' 
#' @import expm
#' @import stats
#' @import mvtnorm
#' @import quantreg
#' 
#' @return the \emph{p}-values and the test statistics of association tests selected by the method option for each SNP.
#' @export QMV_test
#' 
#' 
#' @examples
#' #Phedata: a dataset for 4000 unrelated individuals and four variables,
#'           including one phenotype and three covariates (i.e., Sex,age and BMI).
#' data(Phedata)
#' #Genotype: a dataset for 4000 unrelated individuals and 31 SNPs.
#' data(Genotype)
#' 
#' #the location tests (i.e., QXcat and QZmax)
#' QMV_test(Genotype,Phedata$Y,
#'          Phedata$Sex,
#'          Covariate=Phedata[,c(-1,-2)],
#'          missing_cutoff=0.15,
#'          MAF_Cutoff=NULL,
#'          MGC_Cutoff=30,
#'          method='location')
#'          
#' #the scale test (i.e., wM3VNA3.3)
#' QMV_test(Genotype,Phedata$Y,
#'          Phedata$Sex,
#'          Covariate=Phedata[,c(-1,-2)],
#'          missing_cutoff=0.15,
#'          MAF_Cutoff=NULL,
#'          MGC_Cutoff=30,
#'          method='scale')
#'  
#' #the joint tests (i.e., QMVXcat and QMVZmax)
#' QMV_test(Genotype,Phedata$Y,
#'          Phedata$Sex,
#'          Covariate=Phedata[,c(-1,-2)],
#'          missing_cutoff=0.15,
#'          MAF_Cutoff=NULL,
#'          MGC_Cutoff=30,
#'          method='joint')
#' 
#' #all of the above association tests
#' QMV_test(Genotype,Phedata$Y,
#'          Phedata$Sex,
#'          Covariate=Phedata[,c(-1,-2)],
#'          missing_cutoff=0.15,
#'          MAF_Cutoff=NULL,
#'          MGC_Cutoff=30,
#'          method='all')
#'
#' @author Yu-Xin Yuan, Zi-Ying Yang and Ji-Yuan Zhou
#' 
#' @references Yang ZY, Liu W, Yuan YX, et al. Robust association tests for quantitative traits on the X chromosome. 2022
#' @references Deng WQ, Mao S, Kalnapenkis A, et al. Analytical strategies to include the X-chromosome in variance heterogeneity analyses: evidence for trait-specific polygenic variance structure. \emph{Genetic Epidemiology}, 2019, \strong{43}: 815-830. 
#' @references Ionita-Laza I, Lee S, Makarov V, et al. Sequence kernel association tests for the combined effect of rare and common variants. \emph{The American Journal of Human Genetics}, 2013, \strong{92}: 841-853. 
#' @references Soave D, Corvol H, Panjwani N, et al. A joint location-scale test improves power to detect associated SNPs, gene sets, and pathways. \emph{The American Journal of Human Genetics}, 2015, \strong{97}: 125–138. 
#' 

QMV_test <- function(Genotype,Y,Sex,
                     Covariate=NULL,
                     missing_cutoff=0.15,
                     MAF_Cutoff=NULL,
                     MGC_Cutoff=30,
                     method='joint'){

  if(method=='location') {
    location <- location_test(Genotype,Y,Sex,Covariate,
                              missing_cutoff,
                              MAF_Cutoff,MGC_Cutoff)
    return(location)
  } else if(method=='scale'){
    scale <- scale_test(Genotype,Y,Sex,Covariate,
                        missing_cutoff,
                        MAF_Cutoff,MGC_Cutoff)
    return(scale)
  } else if(method=='joint'){
    location <- location_test(Genotype,Y,Sex,Covariate,
                              missing_cutoff,
                              MAF_Cutoff,MGC_Cutoff)
    scale <- scale_test(Genotype,Y,Sex,Covariate,
                        missing_cutoff,
                        MAF_Cutoff,MGC_Cutoff)
    QMV <- matrix(nrow = nrow(location$pvalue),ncol=4)
    log_location <- log(location$pvalue[,-1,drop=F])
    log_scale <- log(scale$pvalue[,-1,drop=F])
    for (i in 1:2) {
      QMV[,i] <- -2*(log_location[,i]+log_scale[,1])
      QMV[,i+2] <- pchisq(QMV[,i],df = 4, lower.tail = FALSE)
    }
    colnames(QMV) <- c('QMVXcat.test','QMVZmax.test','QMVXcat.p','QMVZmax.p')
    Tstat <- data.frame(SNP=location$pvalue[,1],QMV[,1:2],row.names = NULL)
    colnames(Tstat) <- c('SNP','QMVXcat','QMVZmax')
    pvalue <- data.frame(SNP=location$pvalue[,1],QMV[,3:4],row.names = NULL)
    colnames(pvalue) <- c('SNP','QMVXcat','QMVZmax')
    results <- list(Tstat=Tstat,pvalue=pvalue)
    return(results)
  }else if(method=='all'){
    location <- location_test(Genotype,Y,Sex,Covariate,
                              missing_cutoff,
                              MAF_Cutoff,MGC_Cutoff)
    scale <- scale_test(Genotype,Y,Sex,Covariate,
                        missing_cutoff,
                        MAF_Cutoff,MGC_Cutoff)
    QMV <- matrix(nrow = nrow(location$pvalue),ncol=4)
    log_location <- log(location$pvalue[,-1,drop=F])
    log_scale <- log(scale$pvalue[,-1,drop=F])
    for (i in 1:2) {
      QMV[,i] <- -2*(log_location[,i]+log_scale[,1])
      QMV[,i+2] <- pchisq(QMV[,i],df = 4, lower.tail = FALSE)
    }
    colnames(QMV) <- c('QMVXcat.test','QMVZmax.test','QMVXcat.p','QMVZmax.p')
    Tstat <- data.frame(SNP=location$Tstat,
                        scale$Tstat[,-1,drop=F],
                        QMV[,1:2],row.names = NULL)
    colnames(Tstat) <- c('SNP','QXcat','QZmax','wM3VNA3.3','QMVXcat','QMVZmax')
    pvalue <- data.frame(SNP=location$pvalue,
                         scale$pvalue[,-1,drop=F],
                         QMV[,3:4],row.names = NULL)
    colnames(pvalue) <- c('SNP','QXcat','QZmax','wM3VNA3.3','QMVXcat','QMVZmax')
    results <- list(Tstat=Tstat,pvalue=pvalue)
    return(results)
  }
}
