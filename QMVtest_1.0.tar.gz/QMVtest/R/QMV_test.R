#' @title A function to obtain the p-values of the location tests, the scale test, the location-scale tests or all
#' @description 
#' A function to obtain the \emph{p}-values of the location tests (i.e., QXcat and QZmax), the scale test (i.e.,wM3VNA3.3), the location-scale tests (i.e., QMVXcat, QMVZmax) or all.This function takes as input the genotype of SNPs (\code{Genotype}), the sex (\code{Sex}), the quantitative trait (\code{Y}) in the sample population, and possibly additional covariates, such as age and BMI. 
#' 
#' @usage 
#' QMV_test(Genotype,Y,Sex,
#'          Covariate=NULL,
#'          missing_cutoff=0.15,
#'          MAF_Cutoff=NULL,
#'          MGC_Cutoff=30,
#'          method='joint')
#' 
#' @param Genotype A numeric genotype matrix with each row as a different individual and each column as a separate SNP. Each genotype should be code as 0, 1 or 2, indicating the number of reference allele. The length/dimension of \code{Genotype} should match that of \code{Y}, \code{Sex} and \code{Covariate}.
#' @param Y A numeric vector of a quantitative trait, such as human height.
#' @param Sex A vector of the genetic sex following PLINK default coding, where males are coded as 1 and females are coded as 2.
#' @param Covariate Optional: a vector or a matrix of covariates, such as age and BMI.
#' @param missing_cutoff Cutoff of the missing rates of SNPs (default=0.15). Any SNPs with missing rates higher than the cutoff will be excluded from the analysis.
#' @param MAF_Cutoff MAF cutoff for common vs rare variants (default=NULL). It should be a numeric value between 0 and 0.5, or NULL. When it is NULL, 1/ sqrt(2 SampleSize) will be used (Ionita-Laza et al. 2013). Only common variants are included in the analysis.
#' @param MGC_Cutoff Cutoff for the minimum genotype count in either females or males (default=30), SNPs whose minimum genotype count are less than this cutoff will not be included in the analysis. This is based on the quality control that SNPs with a minimum count below 30 should be removed to avoid inflated type I errors (Deng et al., 2019; Soave et al., 2015).
#' @param method A character string indicating which kind of association tests is to be conducted. There are four options: "location", "scale" , "joint" (default) and "all". method="location": QXcat and QZmax; method="scale": wM3VNA3.3; method="joint": QMVXcat and QMVZmax; method="all": All of the above association tests.
#' 
#' @details 
#' QMVXcat and QMVZmax are designed to test for both the mean differences and the variance heterogeneity of the trait value across genotypes. QXcat and QZmax are used for testing the mean differences of the trait value only. wM3VNA3.3 is for testing the variance heterogeneity only.
#' 
#' @import expm
#' @import stats
#' @import mvtnorm
#' @import quantreg
#' 
#' @return \emph{p}-values of association tests selected by the method option for each SNP.
#' @export QMV_test
#' 
#' 
#' @examples
#' #Phedata: phenotype (Y) and covariates (Sex, age and BMI) data for 4000 unrelated individuals
#' data(Phedata)
#' #Genotype: a data for 4000 unrelated individuals and 31 SNPs
#' data(Genotype)
#' 
#' #the location tests (i.e., QXcat and QZmax)
#' QMV_test(Genotype,Phedata$Y,
#'          Phedata$Sex,
#'          Covariate=Phedata[,c(-1,-2)],
#'          missing_cutoff=0.15,
#'          MAF_Cutoff=NULL,
#'          MGC_Cutoff=30,
#'          method='location')
#'          
#' #the scale test (i.e., wM3VNA3.3)
#' QMV_test(Genotype,Phedata$Y,
#'          Phedata$Sex,
#'          Covariate=Phedata[,c(-1,-2)],
#'          missing_cutoff=0.15,
#'          MAF_Cutoff=NULL,
#'          MGC_Cutoff=30,
#'          method='scale')
#'  
#' #the joint tests (i.e., QMVXcat and QMVZmax)
#' QMV_test(Genotype,Phedata$Y,
#'          Phedata$Sex,
#'          Covariate=Phedata[,c(-1,-2)],
#'          missing_cutoff=0.15,
#'          MAF_Cutoff=NULL,
#'          MGC_Cutoff=30,
#'          method='joint')
#' 
#' #All of the above association tests
#' QMV_test(Genotype,Phedata$Y,
#'          Phedata$Sex,
#'          Covariate=Phedata[,c(-1,-2)],
#'          missing_cutoff=0.15,
#'          MAF_Cutoff=NULL,
#'          MGC_Cutoff=30,
#'          method='all')
#'
#' @author Yu-Xin Yuan, Zi-Ying Yang and Ji-Yuan Zhou
#' 
#' @references Yang ZY, Liu W, Yuan YX, et al. Robust association tests for quantitative traits on the X chromosome. 2022
#' @references Deng WQ, Mao S, Kalnapenkis A, et al. Analytical strategies to include the X-chromosome in variance heterogeneity analyses: Evidence for trait-specific polygenic variance structure. \emph{Genetic Epidemiology}, 2019, \strong{43}: 815-830. 
#' @references Ionita-Laza I, Lee S, Makarov V, et al. Sequence kernel association tests for the combined effect of rare and common variants. \emph{The American Journal of Human Genetics}, 2013, \strong{92}: 841-853. 
#' @references Soave D, Corvol H, Panjwani N, et al. A Joint Location-Scale Test Improves Power to Detect Associated SNPs, Gene Sets, and Pathways. \emph{The American journal of human genetics}, 2015, \strong{97}: 125–138. 
#' 

QMV_test <- function(Genotype,Y,Sex,
                     Covariate=NULL,
                     missing_cutoff=0.15,
                     MAF_Cutoff=NULL,
                     MGC_Cutoff=30,
                     method='joint'){

  if(method=='location') {
    location <- location_test(Genotype,Y,Sex,Covariate,
                              missing_cutoff,
                              MAF_Cutoff,MGC_Cutoff)
    return(location)
  } else if(method=='scale'){
    scale <- scale_test(Genotype,Y,Sex,Covariate,
                        missing_cutoff,
                        MAF_Cutoff,MGC_Cutoff)
    return(scale)
  } else if(method=='joint'){
    location <- location_test(Genotype,Y,Sex,Covariate,
                              missing_cutoff,
                              MAF_Cutoff,MGC_Cutoff)
    scale <- scale_test(Genotype,Y,Sex,Covariate,
                        missing_cutoff,
                        MAF_Cutoff,MGC_Cutoff)
    n_location <- ncol(location[,-1,drop=F])
    n_scale <- ncol(scale[,-1,drop=F])
    QMV <- matrix(nrow = nrow(location),ncol=n_location*n_scale)
    log_location <- log(location[,-1,drop=F])
    log_scale <- log(scale[,-1,drop=F])
    for (i in seq(n_location)) {
      for (j in seq(n_scale)) {
        QMV[,i+n_location*(j-1)] <- pchisq(-2*(log_location[,i]+log_scale[,j]),df = 4, lower.tail = FALSE)
      }
    }
    colnames(QMV) <- c('QMVXcat','QMVZmax')
    QMVres <- data.frame(SNP=location[,1],QMV,row.names = NULL)
    return(QMVres)
  }else if(method=='all'){
    location <- location_test(Genotype,Y,Sex,Covariate,
                              missing_cutoff,
                              MAF_Cutoff,MGC_Cutoff)
    scale <- scale_test(Genotype,Y,Sex,Covariate,
                        missing_cutoff,
                        MAF_Cutoff,MGC_Cutoff)
    n_location <- ncol(location[,-1,drop=F])
    n_scale <- ncol(scale[,-1,drop=F])
    QMV <- matrix(nrow = nrow(location),ncol=n_location*n_scale)
    log_location <- log(location[,-1,drop=F])
    log_scale <- log(scale[,-1,drop=F])
    for (i in seq(n_location)) {
      for (j in seq(n_scale)) {
        QMV[,i+n_location*(j-1)] <- pchisq(-2*(log_location[,i]+log_scale[,j]),df = 4, lower.tail = FALSE)
      }
    }
    colnames(QMV) <- c('QMVXcat','QMVZmax')
    results <- data.frame(location,scale[,-1,drop=F],QMV,row.names = NULL)
    return(results)
  }
}