#' @title Robust association tests for quantitative traits on the X chromosome
#' @description 
#' This function takes as input the genotype of SNPs (\code{Genotype}), the SEX (\code{Sex}), a quantitative trait (\code{Y}) in a sample population, and possibly additional covariates, such as principal components. The function returns the robust X-chromosomal association \emph{p}-values for each SNP (Yang et al., 2021).
#' 
#' @usage 
#' QMV_test(Genotype,Y,Sex,
#'          Covariate=NULL,
#'          missing_cutoff=0.15,
#'          MAF_Cutoff=NULL,
#'          MGC_Cutoff=30,
#'          method='location')
#' 
#' @param Genotype a numeric genotype matrix with each row as a different individual and each column as a separate snp, must contain values 0, 1, 2's coded for the number of reference allele. The length/dimension of \code{Genotype} should match that of \code{Y}, and/or \code{Sex} and \code{Covariate}.
#' @param Y a numeric vector of quantitative trait, such as human height.
#' @param Sex the genetic sex of individuals in the sample population, must be a vector of 1's and 2's following PLINK default coding, where males are coded as 1 and females 2.
#' @param Covariate optional: a vector or a matrix of covariates, such as age, BMI or principal components.
#' @param missing_cutoff a cutoff of the missing rates of SNPs (default=0.15). Any SNPs with missing rates higher than the cutoff will be excluded from the analysis.
#' @param MAF_Cutoff MAF cutoff for common vs rare variants (default=NULL). It should be a numeric value between 0 and 0.5, or NULL. When it is NULL, 1/ sqrt(2 SampleSize) will be used. Only common variants are included in the analysis.
#' @param MGC_Cutoff Cutoff for the minimum genotype count in either females/males (default=30), SNPs whose minimum genotype count are less than this Cutoff will not be included in the analysis. This is based on the quality control that SNPs with a minimum count below 30 should be removed to avoid inflated type I errors (Deng et al., 2019; Soave et al., 2015).
#' @param method a character string indicating which kind of association tests is to be computed. One of "location"(default), "scale" , "joint" or "all": can be abbreviated.method="location": QXcat and QZmax; method="scale": wM3VNA3.3; method="joint": QMVXcat and QMVZmax; method="all": All of the above association tests.
#' 
#' @details 
#' QXcat and QZmax: Sex stratified X chromosome location (mean-based association) tests; wM3VNA3.3: Model-based three-degree of freedom test for variance heterogeneity associated with non-additive genotype;  QMVXcat (QMVZmax): combining the \emph{p}-value of QXcat (QZmax) with that of wM3VNA3.3, which tests for both the difference of means and that of variances.
#' 
#' @import expm
#' @import stats
#' @import mvtnorm
#' @import quantreg
#' 
#' @return robust association \emph{p}-values for each SNP.
#' @export QMV_test
#' 
#' 
#' @examples
#' #Phedata: phenotype(Y) and covariates(Sex,age and BMI) data for 4000 individuals
#' data(Phedata)
#' #Genotype: a data for 4000 individuals and 31 SNPs
#' data(Genotype)
#' 
#' #location tests: QXcat and QZmax
#' QMV_test(Genotype,Phedata$Y,
#'          Phedata$Sex,
#'          Covariate=Phedata[,c(-1,-2)],
#'          missing_cutoff=0.15,
#'          MAF_Cutoff=NULL,
#'          MGC_Cutoff=10,
#'          method='location')
#'          
#' #scale test: wM3VNA3.3
#' QMV_test(Genotype,Phedata$Y,
#'          Phedata$Sex,
#'          Covariate=Phedata[,c(-1,-2)],
#'          missing_cutoff=0.15,
#'          MAF_Cutoff=NULL,
#'          MGC_Cutoff=10,
#'          method='scale')
#'  
#' #joint tests: QMVXcat and QMVZmax
#' QMV_test(Genotype,Phedata$Y,
#'          Phedata$Sex,
#'          Covariate=Phedata[,c(-1,-2)],
#'          missing_cutoff=0.15,
#'          MAF_Cutoff=NULL,
#'          MGC_Cutoff=10,
#'          method='joint')
#' 
#' #All of the above association tests
#' QMV_test(Genotype,Phedata$Y,
#'          Phedata$Sex,
#'          Covariate=Phedata[,c(-1,-2)],
#'          missing_cutoff=0.15,
#'          MAF_Cutoff=NULL,
#'          MGC_Cutoff=10,
#'          method='all')
#'
#' @author Zi-Ying Yang, Wei Liu, Yu-Xin Yuan and Ji-Yuan Zhou
#' 
#' @references Zi-Ying Yang, Wei Liu, Yu-Xin Yuan, Yi-Fan Kong, Pei-Zhen Zhao, Wing Kam Fung and Ji-Yuan Zhou. (2022) Robust association tests for quantitative traits on the X chromosome.
#' @references Wei Q. Deng, Shihong Mao, Anette Kalnapenkis, Tõnu Esko, Reedik Mägi, Guillaume Paré and Lei Sun. (2019) Analytical strategies to include the X-chromosome in variance heterogeneity analyses: Evidence for trait-specific polygenic variance structure. \emph{Genet Epidemiol}. \strong{43}(7):815-830. \doi{10.1002/gepi.22247}. PMID:31332826.
#' @references David Soave, Harriet Corvol, Naim Panjwani, Jiafen Gong, Weili Li, Pierre-Yves Boëlle, Peter R. Durie, Andrew D. Paterson, Johanna M. Rommens, Lisa J. Strug and Lei Sun. (2015) A Joint Location-Scale Test Improves Power to Detect Associated SNPs, Gene Sets, and Pathways. \emph{American journal of human genetics}. \strong{97}(1): 125–138. \doi{10.1016/j.ajhg.2015.05.015}. PMID: 26140448.
#' @references Peng Wang, Si-Qi Xu, Bei-Qi Wang, Wing Kam Fung and Ji-Yuan Zhou. (2019) A robust and powerful test for case-control genetic association study on X chromosome. \emph{Statistical Methods in Medical Research}. \strong{28}(10-11):3260-3272. \doi{10.1177/0962280218799532}. PMID: 30232923.
#' 

QMV_test <- function(Genotype,Y,Sex,
                     Covariate=NULL,
                     missing_cutoff=0.15,
                     MAF_Cutoff=NULL,
                     MGC_Cutoff=30,
                     method='location'){

  #method: a character string indicating which kind of association tests is to be computed. One of "location"(default), "scale" , "joint" or "all": can be abbreviated.
  #method="location": QXcat and QZmax; method="scale": wM3VNA3.3; 
  #method="joint": QMVXcat and QMVZmax; method="all": All of the above association tests
  
  if(method=='location') {
    location <- location_test(Genotype,Y,Sex,Covariate,
                              missing_cutoff,
                              MAF_Cutoff,MGC_Cutoff)
    return(location)
  } else if(method=='scale'){
    scale <- scale_test(Genotype,Y,Sex,Covariate,
                        missing_cutoff,
                        MAF_Cutoff,MGC_Cutoff)
    return(scale)
  } else if(method=='joint'){
    location <- location_test(Genotype,Y,Sex,Covariate,
                              missing_cutoff,
                              MAF_Cutoff,MGC_Cutoff)
    scale <- scale_test(Genotype,Y,Sex,Covariate,
                        missing_cutoff,
                        MAF_Cutoff,MGC_Cutoff)
    n_location <- ncol(location[,-1,drop=F])
    n_scale <- ncol(scale[,-1,drop=F])
    QMV <- matrix(nrow = nrow(location),ncol=n_location*n_scale)
    log_location <- log(location[,-1,drop=F])
    log_scale <- log(scale[,-1,drop=F])
    for (i in seq(n_location)) {
      for (j in seq(n_scale)) {
        QMV[,i+n_location*(j-1)] <- pchisq(-2*(log_location[,i]+log_scale[,j]),df = 4, lower.tail = FALSE)
      }
    }
    colnames(QMV) <- c('QMVXcat','QMVZmax')
    QMVres <- data.frame(SNP=location[,1],QMV,row.names = NULL)
    return(QMVres)
  }else if(method=='all'){
    location <- location_test(Genotype,Y,Sex,Covariate,
                              missing_cutoff,
                              MAF_Cutoff,MGC_Cutoff)
    scale <- scale_test(Genotype,Y,Sex,Covariate,
                        missing_cutoff,
                        MAF_Cutoff,MGC_Cutoff)
    n_location <- ncol(location[,-1,drop=F])
    n_scale <- ncol(scale[,-1,drop=F])
    QMV <- matrix(nrow = nrow(location),ncol=n_location*n_scale)
    log_location <- log(location[,-1,drop=F])
    log_scale <- log(scale[,-1,drop=F])
    for (i in seq(n_location)) {
      for (j in seq(n_scale)) {
        QMV[,i+n_location*(j-1)] <- pchisq(-2*(log_location[,i]+log_scale[,j]),df = 4, lower.tail = FALSE)
      }
    }
    colnames(QMV) <- c('QMVXcat','QMVZmax')
    results <- data.frame(location,scale[,-1,drop=F],QMV,row.names = NULL)
    return(results)
  }
}