#' @title Read Plink Raw files into R, and perform robust association tests for quantitative traits on the X chromosome
#' @description 
#' This function takes as input the path to file with extension ".raw" (\code{ped_raw_path}), the Path to file with extension ".map" (\code{map_path}), and possibly additional path to file with covariates (\code{Covariate_path}) in a sample population. The function returns the robust X-chromosomal association \emph{p}-values for each SNP (Yang et al., 2021).
#' 
#' @usage
#' QMV_test_ped(ped_raw_path,trait_missing=NA,
#'              Genotype_missing=NA,
#'              ped_raw.header=FALSE,
#'              Covariate_path=NULL,
#'              Covariate_missing = NA,
#'              Covariate.header=FALSE,
#'              map_path=NULL,map_header=FALSE,
#'              missing_cutoff=0.15,
#'              MAF_Cutoff=NULL,MGC_Cutoff=30,
#'              method='location')
#' 
#' @param ped_raw_path Path to file with extension ".raw" to read. Plink raw format, produced by "--recode A" for use with R. A text file with a header line, and then one line per sample with V+6 (for "--recode A") fields, where V is the number of variants. The first six fields are: Family ID (FID), Individual ID  (IID), 	Paternal within-family ID (PID), Maternal within-family ID (MID), Sex and Main phenotype value(Phenotype). This is followed by one fields per variant: Allelic dosage (0/1/2/'NA' for diploid variants). Either Paternal's or Maternal's ID is set to 0 for founders, i.e. individuals with no parents. Numeric coding for Sex is 0 = unknown, 1 = male, 2 = female. For quantitative traits, phenotypes are individuals' trait values. The ped provided to this function should only contain SNPs on X chromosome. The male individuals are hemizygote at all the SNPs on X chromosome.
#' @param trait_missing The input variable "trait_missing" is the missing value for the trait in the data file, and the default value is NA. It may be -9 in some data files; or other numeric value.
#' @param Genotype_missing 	The input variable "Genotype_missing" represents that the genotype at the locus is missing, and the default value is NA. It may be -9 in some data files; or other numeric value.
#' @param ped_raw.header Logical scalar defaulting to False (or F) indicating whether the ped file contains variable names or not.
#' @param Covariate_path Path to file with covariates to read. The covariates needed to be adjusted, a text file with a header line, and one line per sample with the following 6+C fields (where C is the number of covariates): Family ID (FID), Individual ID  (IID), 	Paternal within-family ID (PID), Maternal within-family ID (MID), Sex and Main phenotype value(Phenotype). This is followed by one fields per covariate.
#' @param Covariate_missing The input variable "covariate_missing" is the missing value for the covariates in the data file, and the default value is NA.
#' @param Covariate.header Logical scalar defaulting to False (or F) indicating whether the covariate file contains variable names or not.
#' @param map_path  Path to file with extension ".map" to read. By default, each line of the MAP file describes a single marker and must contain exactly 4 columns:chromosome (1-22, X, Y or 0 if unplaced), rs# or snp identifier, Genetic distance (morgans) and Base-pair position (bp units).
#' @param map_header Logical scalar defaulting to False (or F) indicating whether the map file contains variable names or not.
#' @param missing_cutoff a cutoff of the missing rates of SNPs (default=0.15). Any SNPs with missing rates higher than the cutoff will be excluded from the analysis.
#' @param MAF_Cutoff MAF cutoff for common vs rare variants (default=NULL). It should be a numeric value between 0 and 0.5, or NULL. When it is NULL, 1/ sqrt(2 SampleSize)  will be used. Only common variants are included in the analysis.
#' @param MGC_Cutoff Cutoff for the minimum genotype count in either females/males (default=30), SNPs whose minimum genotype count are less than this Cutoff will not be included in the analysis. This is based on the quality control that SNPs with a minimum count below 30 should be removed to avoid inflated type I errors (Deng et al., 2019; Soave et al., 2015).
#' @param method a character string indicating which kind of association tests is to be computed. One of "location"(default), "scale" , "joint" or "all": can be abbreviated.method="location": QXcat and QZmax; method="scale": wM3VNA3.3; method="joint": QMVXcat and QMVZmax; method="all": All of the above association tests.
#' 
#' 
#' @import expm
#' @import stats
#' @import mvtnorm
#' @import quantreg
#' @importFrom utils read.table
#' 
#' @return robust association \emph{p}-values for each SNP.
#' @export QMV_test_ped
#' 
#' @examples
#' 
#' path <- system.file("extdata", package = "QMVtest")
#' 
#' QMV_test_ped(paste(path,"example.raw",sep = '/'),trait_missing=NA,
#'              Genotype_missing=NA,
#'              ped_raw.header=FALSE,
#'              Covariate_path=paste(path,"Covariate.txt",sep = '/'),
#'              Covariate_missing = NA,
#'              Covariate.header=TRUE,
#'              map_path=paste(path,"example.map",sep = '/'),
#'              map_header=FALSE,
#'              missing_cutoff=0.15,
#'              MAF_Cutoff=NULL,
#'              MGC_Cutoff=30,
#'              method='location')
#' 
#' @author Zi-Ying Yang, Wei Liu, Yu-Xin Yuan and Ji-Yuan Zhou
#' 
#' @references Zi-Ying Yang, Wei Liu, Yu-Xin Yuan, Yi-Fan Kong, Pei-Zhen Zhao, Wing Kam Fung and Ji-Yuan Zhou. (2022) Robust association tests for quantitative traits on the X chromosome.
#' @references Wei Q. Deng, Shihong Mao, Anette Kalnapenkis, Tõnu Esko, Reedik Mägi, Guillaume Paré and Lei Sun. (2019) Analytical strategies to include the X-chromosome in variance heterogeneity analyses: Evidence for trait-specific polygenic variance structure. \emph{Genet Epidemiol}. \strong{43}(7):815-830. \doi{10.1002/gepi.22247}. PMID:31332826.
#' @references David Soave, Harriet Corvol, Naim Panjwani, Jiafen Gong, Weili Li, Pierre-Yves Boëlle, Peter R. Durie, Andrew D. Paterson, Johanna M. Rommens, Lisa J. Strug and Lei Sun. (2015) A Joint Location-Scale Test Improves Power to Detect Associated SNPs, Gene Sets, and Pathways. \emph{American journal of human genetics}. \strong{97}(1): 125–138. \doi{10.1016/j.ajhg.2015.05.015}. PMID: 26140448.
#' @references Peng Wang, Si-Qi Xu, Bei-Qi Wang, Wing Kam Fung and Ji-Yuan Zhou. (2019) A robust and powerful test for case-control genetic association study on X chromosome. \emph{Statistical Methods in Medical Research}. \strong{28}(10-11):3260-3272. \doi{10.1177/0962280218799532}. PMID: 30232923.
#' 

QMV_test_ped <- function(ped_raw_path,trait_missing=NA,
                         Genotype_missing=NA,
                         ped_raw.header=FALSE,
                         Covariate_path=NULL,
                         Covariate_missing = NA,
                         Covariate.header=FALSE,
                         map_path=NULL,map_header=FALSE,
                         missing_cutoff=0.15,
                         MAF_Cutoff=NULL,MGC_Cutoff=30,
                         method='location'){
  
  pedfile <- read.table(ped_raw_path,header = ped_raw.header)
  if(!is.null(map_path)){
    mapfile <- read.table(map_path,header = map_header)
    colnames(mapfile) <- c('chromosome','marker.ID',
                           'genetic.dist','physical.pos')
    if((ncol(pedfile)-6)!=nrow(mapfile)){
      stop('Each line of the MAP file describes a single marker ')
    }
    colnames(pedfile) <- c('FID','IID','PID','MID',
                           'Sex','Phenotype',mapfile[,2])
  } else{
    if(ped_raw.header){
      colnames(pedfile)[1:6] <- c('FID','IID','PID','MID',
                                  'Sex','Phenotype')
    } else{
      colnames(pedfile) <- c('FID','IID','PID','MID',
                             'Sex','Phenotype',
                             paste('snp',seq(ncol(pedfile)-6),sep='_'))
    }
  }
  pedfile$Sex[pedfile$Sex==0] <- NA
  if(!is.na(trait_missing)){
    pedfile$Phenotype[pedfile$Phenotype==trait_missing] <- NA
  }
  if(!is.na(Genotype_missing)){
    pedfile[,-6:-1] <- apply(pedfile[,-6:-1],2,function(x){
      x[x==Genotype_missing] <- NA
      return(x)
    })
  }
  if(!is.null(Covariate_path)){
    Covarfile <- read.table(Covariate_path,header = Covariate.header)
    if(Covariate.header==FALSE){
      colnames(Covarfile) <- c('FID','IID','PID','MID',
                               'Sex','Phenotype',
                               paste('Covar',1:(ncol(Covarfile)-6),sep='_'))
    } else{
      colnames(Covarfile)[1:6] <- c('FID','IID','PID','MID',
                                    'Sex','Phenotype')
    }
    if(!is.na(Covariate_missing)){
      Covarfile[,-6:-1] <- apply(Covarfile[,-6:-1],2,function(x){
        x[x==Covariate_missing] <- NA
        return(x)
      })
    }
    merge_data <- merge(pedfile,Covarfile[,-3:-6], 
                        by=c("FID","IID"),sort = FALSE)
    pedata <- merge_data[,seq(ncol(pedfile))]
    Covdata <- merge_data[,-seq(ncol(pedfile))]
  } else{
    pedata <- pedfile
    Covdata <- NULL
  }
  test_res <- QMV_test(pedata[,-1:-6],Y=pedata$Phenotype,
                       Sex = pedata$Sex,Covariate=Covdata,
                       missing_cutoff,
                       MAF_Cutoff,
                       MGC_Cutoff,
                       method)
  if(!is.null(map_path)){
    results <- merge(mapfile,test_res,by.x='marker.ID',
                     by.y='SNP',sort = FALSE)
    return(results)
  } else{
    return(test_res)
  }
}