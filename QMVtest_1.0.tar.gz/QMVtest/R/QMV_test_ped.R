#' @title Read PLINK raw files into R, and compute the p-values of the location tests, the scale test, the location-scale tests or all
#' @description 
#' A function to obtain the \emph{p}-values of the location tests (i.e., QXcat and QZmax), the scale test (i.e.,wM3VNA3.3), the location-scale tests (i.e., QMVXcat, QMVZmax) or all. This function takes as input the path to the file of genotype with extension ".raw" (\code{ped_raw_path}), the path to the file of SNP information with extension ".map" (\code{map_path}), and possibly additional path to the file of covariates (\code{Covariate_path}) in the sample population.
#' 
#' @usage
#' QMV_test_ped(ped_raw_path,trait_missing=NA,
#'              Genotype_missing=NA,
#'              ped_raw.header=FALSE,
#'              Covariate_path=NULL,
#'              Covariate_missing = NA,
#'              Covariate.header=FALSE,
#'              map_path=NULL,map_header=FALSE,
#'              missing_cutoff=0.15,
#'              MAF_Cutoff=NULL,
#'              MGC_Cutoff=30,
#'              method='joint')
#' 
#' @param ped_raw_path Path to the file of genotype with extension ".raw" to read, which is produced by "--recode A" in PLINK for use with R. This file should be a text file, one line per sample, with V+6 columns, where V is the number of variants. The first six columns are: Family ID (FID), Individual ID  (IID), Paternal within-family ID (PID), Maternal within-family ID (MID), Sex and Phenotype, followed by one column per variant.
#' @param trait_missing The input variable "trait_missing" is the missing value for the trait in the raw file, and the default value is NA. It may be -9 in some raw files; or other numeric value.
#' @param Genotype_missing 	The input variable "Genotype_missing" represents that the genotype at the locus in the raw file is missing, and the default value is NA. It may be -9 in some raw files; or other numeric value.
#' @param ped_raw.header Logical scalar defaulting to False (or F) indicating whether the raw file contains variable names or not.
#' @param Covariate_path Path to the file of possibly additional covariates to read. This file should be a text file, one line per sample, with C+6 columns, where C is the number of covariates. The former six columns should be Family ID (FID), Individual ID  (IID), Paternal within-family ID (PID), Maternal within-family ID (MID), Sex and Phenotype. 
#' @param Covariate_missing The input variable "covariate_missing" is the missing value for the covariates in the data file, and the default value is NA.
#' @param Covariate.header Logical scalar defaulting to False (or F) indicating whether the covariate file contains variable names or not.
#' @param map_path  Path to the file of SNP information with extension ".map" to read. Each line of the map file describes a SNP and must contain four columns: chromosome (1-22, X, Y or 0 if unplaced), rs# or SNP identifier, genetic distance (morgans) and base-pair position (bp units).
#' @param map_header Logical scalar defaulting to False (or F) indicating whether the map file contains variable names or not.
#' @param missing_cutoff Cutoff of the missing rates of SNPs (default=0.15). Any SNPs with missing rates higher than the cutoff will be excluded from the analysis.
#' @param MAF_Cutoff MAF cutoff for common vs rare variants (default=NULL). It should be a numeric value between 0 and 0.5, or NULL. When it is NULL, 1/ sqrt(2 SampleSize) will be used (Ionita-Laza et al. 2013). Only common variants are included in the analysis.
#' @param MGC_Cutoff Cutoff for the minimum genotype count in either females or males (default=30), SNPs whose minimum genotype count are less than this cutoff will not be included in the analysis. This is based on the quality control that SNPs with a minimum count below 30 should be removed to avoid inflated type I errors (Deng et al., 2019; Soave et al., 2015).
#' @param method A character string indicating which kind of association tests is to be conducted. There are four options: "location", "scale" , "joint" (default) and "all". method="location": QXcat and QZmax; method="scale": wM3VNA3.3; method="joint": QMVXcat and QMVZmax; method="all": All of the above association tests.
#' 
#' @details 
#' QMVXcat and QMVZmax are designed to test for both the mean differences and the variance heterogeneity of the trait value across genotypes. QXcat and QZmax are used for testing the mean differences of the trait value only. wM3VNA3.3 is for testing the variance heterogeneity only.
#' 
#' @import expm
#' @import stats
#' @import mvtnorm
#' @import quantreg
#' @importFrom utils read.table
#' 
#' @return \emph{p}-values of association tests selected by the method option for each SNP.
#' @export QMV_test_ped
#' 
#' @examples
#' 
#' path <- system.file("extdata", package = "QMVtest")
#' 
#' QMV_test_ped(paste(path,"example.raw",sep = '/'),trait_missing=NA,
#'              Genotype_missing=NA,
#'              ped_raw.header=FALSE,
#'              Covariate_path=paste(path,"Covariate.txt",sep = '/'),
#'              Covariate_missing = NA,
#'              Covariate.header=TRUE,
#'              map_path=paste(path,"example.map",sep = '/'),
#'              map_header=FALSE,
#'              missing_cutoff=0.15,
#'              MAF_Cutoff=NULL,
#'              MGC_Cutoff=30,
#'              method='joint')
#' 
#' @author Yu-Xin Yuan, Zi-Ying Yang and Ji-Yuan Zhou
#' 
#' @references Yang ZY, Liu W, Yuan YX, et al. Robust association tests for quantitative traits on the X chromosome. 2022
#' @references Deng WQ, Mao S, Kalnapenkis A, et al. Analytical strategies to include the X-chromosome in variance heterogeneity analyses: Evidence for trait-specific polygenic variance structure. \emph{Genetic Epidemiology}, 2019, \strong{43}: 815-830. 
#' @references Ionita-Laza I, Lee S, Makarov V, et al. Sequence kernel association tests for the combined effect of rare and common variants. \emph{The American Journal of Human Genetics}, 2013, \strong{92}: 841-853. 
#' @references Soave D, Corvol H, Panjwani N, et al. A Joint Location-Scale Test Improves Power to Detect Associated SNPs, Gene Sets, and Pathways. \emph{The American journal of human genetics}, 2015, \strong{97}: 125–138. 
#' 

QMV_test_ped <- function(ped_raw_path,trait_missing=NA,
                         Genotype_missing=NA,
                         ped_raw.header=FALSE,
                         Covariate_path=NULL,
                         Covariate_missing = NA,
                         Covariate.header=FALSE,
                         map_path=NULL,map_header=FALSE,
                         missing_cutoff=0.15,
                         MAF_Cutoff=NULL,
                         MGC_Cutoff=30,
                         method='joint'){
  
  pedfile <- read.table(ped_raw_path,header = ped_raw.header)
  if(!is.null(map_path)){
    mapfile <- read.table(map_path,header = map_header)
    colnames(mapfile) <- c('chromosome','marker.ID',
                           'genetic.dist','physical.pos')
    if((ncol(pedfile)-6)!=nrow(mapfile)){
      stop('Each line of the MAP file describes a single marker ')
    }
    colnames(pedfile) <- c('FID','IID','PID','MID',
                           'Sex','Phenotype',mapfile[,2])
  } else{
    if(ped_raw.header){
      colnames(pedfile)[1:6] <- c('FID','IID','PID','MID',
                                  'Sex','Phenotype')
    } else{
      colnames(pedfile) <- c('FID','IID','PID','MID',
                             'Sex','Phenotype',
                             paste('snp',seq(ncol(pedfile)-6),sep='_'))
    }
  }
  pedfile$Sex[pedfile$Sex==0] <- NA
  if(!is.na(trait_missing)){
    pedfile$Phenotype[pedfile$Phenotype==trait_missing] <- NA
  }
  if(!is.na(Genotype_missing)){
    pedfile[,-6:-1] <- apply(pedfile[,-6:-1],2,function(x){
      x[x==Genotype_missing] <- NA
      return(x)
    })
  }
  if(!is.null(Covariate_path)){
    Covarfile <- read.table(Covariate_path,header = Covariate.header)
    if(Covariate.header==FALSE){
      colnames(Covarfile) <- c('FID','IID','PID','MID',
                               'Sex','Phenotype',
                               paste('Covar',1:(ncol(Covarfile)-6),sep='_'))
    } else{
      colnames(Covarfile)[1:6] <- c('FID','IID','PID','MID',
                                    'Sex','Phenotype')
    }
    if(!is.na(Covariate_missing)){
      Covarfile[,-6:-1] <- apply(Covarfile[,-6:-1],2,function(x){
        x[x==Covariate_missing] <- NA
        return(x)
      })
    }
    merge_data <- merge(pedfile,Covarfile[,-3:-6], 
                        by=c("FID","IID"),sort = FALSE)
    pedata <- merge_data[,seq(ncol(pedfile))]
    Covdata <- merge_data[,-seq(ncol(pedfile))]
  } else{
    pedata <- pedfile
    Covdata <- NULL
  }
  test_res <- QMV_test(pedata[,-1:-6],Y=pedata$Phenotype,
                       Sex = pedata$Sex,Covariate=Covdata,
                       missing_cutoff,
                       MAF_Cutoff,
                       MGC_Cutoff,
                       method)
  if(!is.null(map_path)){
    results <- merge(mapfile,test_res,by.x='marker.ID',
                     by.y='SNP',sort = FALSE)
    return(results)
  } else{
    return(test_res)
  }
}